import UIKit

// Merge Sort divides the input into possible halves with 2 elements and then sorts them (Divide -> Conquer -> Combine)
// Stable Algorithm
// Time Complexity = O(n log n)
// Space Complexity = O(n)

func mergeSort(inputArray: [Int]) -> [Int] {
    if inputArray.count <= 1 { return inputArray }
    
    let middleIndex = inputArray.count / 2
    
    var leftArray = Array(inputArray.prefix(upTo: middleIndex))
    var rightArray = Array(inputArray.suffix(from: middleIndex))
    
    leftArray = mergeSort(inputArray: leftArray)
    rightArray = mergeSort(inputArray: rightArray)
    
    return merge(leftArray: leftArray, rightArray: rightArray)
}

func merge(leftArray: [Int], rightArray: [Int]) -> [Int] {
    var result: [Int] = []
    
    var leftArrayIndex = 0
    var rightArrayIndex = 0
    
    while leftArrayIndex < leftArray.count && rightArrayIndex < rightArray.count {
        let leftElement = leftArray[leftArrayIndex]
        let rightElement = rightArray[rightArrayIndex]
        
        
        if leftElement <= rightElement {
            result.append(leftElement)
            leftArrayIndex += 1
        } else if leftElement > rightElement {
            result.append(rightElement)
            rightArrayIndex += 1
        } else {
            result.append(leftElement)
            leftArrayIndex += 1
            result.append(rightElement)
            rightArrayIndex += 1
        }
    }
    
    while leftArrayIndex < leftArray.count {
        result.append(leftArray[leftArrayIndex])
        leftArrayIndex += 1
    }
    
    while rightArrayIndex < rightArray.count {
        result.append(rightArray[rightArrayIndex])
        rightArrayIndex += 1
    }
    return result
}

mergeSort(inputArray: [2, 4, 1, 6, 3, 8, 7, 9, 5])
