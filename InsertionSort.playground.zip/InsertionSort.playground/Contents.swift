import UIKit

// Insertion Sort algorithm iterates through an input array and removes one element per iteration, finds its place in the array and places it there (from left to right)
// Stable
// Time Complexity = O(n^2)
// Space Complexity = O(1)
func insertionSort<T: Comparable>(input: [T]) -> [T] {
    guard input.count > 1 else { return input }
    
    var result = input
    for (index, element) in input.enumerated() {
        var comparingIndex = index - 1
        while comparingIndex >= 0 && result[comparingIndex] > element {
            result[comparingIndex + 1] = result[comparingIndex]
            comparingIndex -= 1
        }
        result[comparingIndex + 1] = element
    }
    return result
}

insertionSort(input: [2, 5, 8, 9, 3, 6, 1, 7, 3, 4, 8])
