
import UIKit

// Bubble Sort algorithm compares each element in the array and swaps them if they are our of order until the entire array is sorted
// Stable
// Time Complexity = O(n^2)
// Space Complexity = O(1)
func bubbleSort<T: Comparable>(input: [T]) -> [T] {
    guard input.count > 1 else { return input }
    
    var result = input
    for _ in 0..<input.count {
        for comparingIndex in 1..<input.count {
            if result[comparingIndex - 1] > result[comparingIndex] {
                result.swapAt(comparingIndex - 1, comparingIndex)
            }
        }
    }
    return result
}

bubbleSort(input: [2, 5, 8, 9, 3, 6, 1, 7, 3, 4, 8])
