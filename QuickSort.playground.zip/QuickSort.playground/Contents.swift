import UIKit

// Quick Sort picks a pivot element and sorts all the elements before it and after it and combines them for a resulting sorted array.
// Not Stable
// Time Complexity = O(n^2)
// Space Complexity = log n

func quickSort<T: Comparable>(input: [T]) -> [T] {
    guard input.count > 1 else { return input }
    
    let pivot = input[input.count / 2]
    
    let lessThanPivotArray = input.filter { $0 < pivot }
    let equalToPivotArray = input.filter { $0 == pivot}
    let greaterThanPivotArray = input.filter { $0 > pivot }
    
    return (quickSort(input: lessThanPivotArray) + equalToPivotArray + quickSort(input: greaterThanPivotArray))
}

quickSort(input: [2, 5, 7, 9, 3, 1, 8, 5, 6, 3])
